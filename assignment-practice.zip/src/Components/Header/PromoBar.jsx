const PromoBar = () => {
  return (
    <div className="bg-[#ff007c] py-1.5 sm:py-2 text-center text-xs sm:text-sm font-bold text-white">
      Nové iPhone 14 PRO s 20% zľavou ✨
    </div>
  );
};

export default PromoBar;
