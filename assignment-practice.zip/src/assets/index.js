export { default as AppleLogo } from "./icons/appleLogo.svg?react";
export { default as Bag } from "./icons/bag.svg?react";
export { default as Cross } from "./icons/cross.svg?react";
export { default as Heart } from "./icons/heart.svg?react";
export { default as LineBtn } from "./icons/lineBtn.svg?react";
export { default as Logo } from "./icons/logo.svg?react";
export { default as Tag } from "./icons/tag.svg?react";
export { default as User } from "./icons/user.svg?react";
export { default as Ranch } from "./icons/ranch.svg?react";
export { default as Discount } from "./icons/discount.svg?react";
export { default as Whiteheart } from "./icons/whiteHeart.svg?react";
export {default as AnimatedHeart} from "./icons/animatedheart.svg?react";
export {default as SmallArrow} from "./icons/smallArrow.svg?react";

export { default as Facebook } from "./icons/facebook.svg?react";
export { default as Instagram } from "./icons/instagram.svg?react";
export { default as Youtube } from "./icons/youtube.svg?react";
export { default as Whatsapp } from "./icons/whatsapp.svg?react";
export { default as Tiktok } from "./icons/tiktok.svg?react";

export { default as Visa } from "./icons/visa.svg?react";
export { default as MasterYellow } from "./icons/masterYellow.svg?react";
export { default as MasterBlue } from "./icons/masterBlue.svg?react";
export { default as AmexCard } from "./icons/amexCard.svg?react";
export { default as GPay } from "./icons/gpay.svg?react";
export { default as ApplePay } from "./icons/applePay.svg?react";
export { default as PayPal } from "./icons/paypal.svg?react";

export { default as Bin } from "./icons/bin.svg?react";
export { default as Van } from "./icons/van.svg?react";
export { default as Star } from "./icons/star.svg?react";
export { default as Dot } from "./icons/dot.svg?react";
export { default as RightArrow } from "./icons/rightArrow.svg?react";
export { default as Close } from "./icons/close.svg?react";
export { default as Plus } from "./icons/plus.svg?react";
export { default as Tick } from "./icons/tick.svg?react";
